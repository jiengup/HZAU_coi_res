#include<stdio.h>
int max(int a,int b);

int main()
{
    int aa,bb,cc;
/*    scanf("%d%d",&aa,&bb);
    printf("max=%d\n",max(aa,bb));*/

    scanf("%d%d%d",&aa,&bb,&cc);
    printf("max=%d\n",max(max(aa,bb),cc));
    return 0;
}

int max(int a,int b)
{
    int m;
    m=a>b ? a:b;
    return m;
}
