from django.contrib import admin
from .models import user
class userAdmin(admin.ModelAdmin):
    #列表显示对应字段
    list_display=("uid","upwd")
#注册model到Admin
admin.site.register(user,userAdmin)

# Register your models here.
