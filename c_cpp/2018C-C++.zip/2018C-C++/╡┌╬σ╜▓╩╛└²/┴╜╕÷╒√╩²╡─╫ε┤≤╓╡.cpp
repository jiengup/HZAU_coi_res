#include<stdio.h>
int main()
{
    int a,b,max,ret;
    printf("Input a,b:");
    ret=scanf("%d,%d",&a,&b);
    while(ret!=2)
    {
        while(getchar()!='\n');
        printf("input a, b:");
        ret=scanf("%d,%d",&a,&b);
    }
    max=a>b?a:b;
    printf("max=%d\n",max);
    return 0;
}
