from django.db import models

# Create your models here.

'''
数据表--类
字段----类下面的一个属性
'''

class student(models.Model):
    sid=models.CharField(max_length=50)
    sname=models.CharField(max_length=50)
    ssex=models.CharField(max_length=50)
    sage=models.CharField(max_length=50)
    sclass=models.CharField(max_length=50)

class user(models.Model):
    uid=models.CharField(max_length=50)
    upwd=models.CharField(max_length=50)
