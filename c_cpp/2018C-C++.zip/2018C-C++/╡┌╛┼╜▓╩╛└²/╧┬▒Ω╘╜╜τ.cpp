#include <stdio.h>

int main()
{
    int a=1,c=2,b[5],i;
    printf("%p,%p,%p\n",b,&a,&c);
    for(i=0;i<=11;i++)
    {
        b[i]=i;
        printf("%d ",b[i]);
    }
    printf("\na=%d, c=%d\n",a,c);
    return 0;
}

