#include  <stdio.h>
main()
{
	int  m = 5;
	printf("m/2=%d\n", m/2);
	printf("(float)(m/2) = %f\n", (float)(m/2));
	printf("(float)m/2 = %f\n", (float)m/2);
	printf("m = %d\n", m);
}
