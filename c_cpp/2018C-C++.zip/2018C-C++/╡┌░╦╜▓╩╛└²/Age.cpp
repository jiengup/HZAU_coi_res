#include<stdio.h>
int age(int n);
int main()
{
    int ith,ret;
    printf("Input the number of ith:");
    scanf("%d",&ith);
    printf("age(%d)= %d\n",ith,age(ith));
    return 0;
}
int age(int n)
{
    int ret;
    if(n==1)
        ret=10;
    else
        ret=age(n-1)+2;
    return (ret);
}
