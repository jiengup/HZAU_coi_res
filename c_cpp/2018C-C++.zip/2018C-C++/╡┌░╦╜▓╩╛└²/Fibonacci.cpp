#include<stdio.h>
long Fib(int n);
int main()
{
    int n,ret;
    printf("Input the number of n:");
    scanf("%d",&n);
    ret=Fib(n);
    printf("Fib(%d)= %d",n,ret);
    return 0;
}
long Fib(int n)
{
	long f;

	if (n == 0) f = 0;
	else if (n == 1) f = 1;
	else f=Fib(n-1) + Fib(n-2);

	return f;
}
