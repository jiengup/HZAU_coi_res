# coding utf-8
import sqlite3

#巧妙：查找当前代码文件所在根目录及各层子目录文件方法"..\\"
conn=sqlite3.connect('..\\db.sqlite3')#无扩展名 
cmd=conn.cursor()
'''
#显示home_student表信息
cmd.execute("select * from home_student")
ds=cmd.fetchall()
for row in ds:
    print(row)

print()

#显示home_user表信息
cmd.execute("select * from home_user")
ds=cmd.fetchall()
for row in ds:
    print(row)

cmd.close()
conn.close()
'''
