#include<stdio.h>
#define N 40
void FindMax(int score[],long num[],int n,int *pmaxscore,long*pmaxnum);

int main()
{
    int score[N],maxScore;
    int n,i;
    long num[N],maxNum;
    printf("How many students?");
    scanf("%d",&n);
    printf("Input students' ID and score:\n");
    for(i=0;i<n;i++)
    {
        scanf("%ld%d",&num[i],&score[i]);
    }

    FindMax(score,num,n,&maxScore,&maxNum);
    printf("maxScore=%d, maxNum=%ld\n",maxScore,maxNum);
    return 0;
}

void FindMax(int score[],long num[],int n,int *pmaxscore,long*pmaxnum)
{
    int i;
    *pmaxscore=score[0];
    *pmaxnum=num[0];
    for(i=1;i<n;i++)
    {
        if(score[i]>*pmaxscore)
        {
            *pmaxscore=score[i];
            *pmaxnum=num[i];
        }
    }/**/
}
