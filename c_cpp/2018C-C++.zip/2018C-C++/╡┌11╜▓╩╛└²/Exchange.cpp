#include <stdio.h>
void exchange(int *x,int *y);
int main()
{
    int a,b;
    printf("please input a and b:\n");
    scanf("%d%d",&a,&b);
    printf("\na=%d\tb=%d",a,b);
    exchange(&a,&b);
    printf("\na=%d\tb=%d",a,b);
    return 0;
}
void exchange(int *x,int *y)
{
    int z;
    z=*x;
    *x=*y;
    *y=z;
    printf("\nx=%d\ty=%d",*x,*y);
}

