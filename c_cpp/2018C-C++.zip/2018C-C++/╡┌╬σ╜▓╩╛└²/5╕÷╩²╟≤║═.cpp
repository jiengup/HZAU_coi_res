#include<stdio.h>
int main()
{
    int i,sum,n;
    sum=0;
    for(i=0;i<5;i++)
    {
        scanf("%d",&n);
        sum=sum+n;
    }
    printf("%d",sum);
    return 0;
}
