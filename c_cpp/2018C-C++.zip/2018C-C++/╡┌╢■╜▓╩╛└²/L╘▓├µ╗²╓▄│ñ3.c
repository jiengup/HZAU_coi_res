#include  <stdio.h>
main()
{
	const double pi = 3.14159;    /* ����ʵ�͵�const����pi */
	double r;
	double circum;
	double area; 
	printf("Input r:");
	scanf("%lf", &r);
	circum = 2 * pi * r;
	area = pi * r * r;                   
	printf("circumference = %f\n", circum);	
	printf("area = %f\n", area);		
}
