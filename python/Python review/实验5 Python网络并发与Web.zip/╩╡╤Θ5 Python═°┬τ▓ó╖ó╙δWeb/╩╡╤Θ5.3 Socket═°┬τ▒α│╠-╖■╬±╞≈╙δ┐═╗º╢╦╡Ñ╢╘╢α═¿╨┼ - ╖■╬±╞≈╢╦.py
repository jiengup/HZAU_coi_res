#实验5.3 Socket网络编程-服务器与客户端通信
#服务器端
import socket
host="127.0.0.1"
port=8123
server=socket.socket()
#server=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.bind((host,port))#绑定要监听的端口
server.listen()#监听
print('开始等待...')
while True:#实时
    conn,addr=server.accept()#
    print('消息来了...','end')
    data=conn.recv(1024)#接收消息
    print("client("+addr[0]+") say:",data.decode('utf-8').strip())
    conn.send("hello client".encode('utf-8'))
server.close()
