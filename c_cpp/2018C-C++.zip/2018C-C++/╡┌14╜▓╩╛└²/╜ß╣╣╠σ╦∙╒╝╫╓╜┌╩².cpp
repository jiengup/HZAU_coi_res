#include<stdio.h>
typedef struct sample
{
    char m1;
    int m2;
    char m3;
}SAMPLE;
int main()
{
    printf("%d\n",sizeof(SAMPLE));
    return 0;
}
