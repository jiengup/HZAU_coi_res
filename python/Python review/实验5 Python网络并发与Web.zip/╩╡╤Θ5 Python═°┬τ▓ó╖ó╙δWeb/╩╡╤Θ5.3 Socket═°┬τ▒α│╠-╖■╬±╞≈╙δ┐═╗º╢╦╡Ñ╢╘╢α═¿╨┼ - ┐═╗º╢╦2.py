#实验5.3 Socket网络编程-服务器与客户端通信
#客户端2
import socket
import tkinter
from tkinter import messagebox

'''
def show(txt,data):
    txt.insert('1.0',data)
'''

root=tkinter.Tk()
root.geometry("512x384")
root.minsize(width=512,height=384) #固定窗口尺寸，禁止缩放
root.maxsize(width=512,height=384)
root.title("Client-2")

def onSend():
    try:
        host="127.0.0.1"
        port=8123
        client=socket.socket()
        client.connect((host,port))
        senddata=v1.get()
        client.send(senddata.encode('utf-8'))#发数据给服务器
        recvdata=client.recv(1024)
        #v2.set(recvdata.decode('utf-8').strip()) #字符缓冲
        n.set(n.get()+1) #计数
        if n.get()==1:
            txt2.insert(1.0,recvdata.decode('utf-8').strip()+", this is 1st sending!\n")#注意单独使用place()，Text.insert才能使用
        elif n.get()==2:
            txt2.insert(1.0,recvdata.decode('utf-8').strip()+", this is 2nd sending!\n")
        elif n.get()==3:
            txt2.insert(1.0,recvdata.decode('utf-8').strip()+", this is 3rd sending!\n")
        else:
            txt2.insert(1.0,recvdata.decode('utf-8').strip()+", this is "+str(n.get())+"th sending!\n") 
        client.close() 
    except:
        import sys
        messagebox.showinfo("提示",sys.exc_info())
        client.close()
        


txt2=tkinter.Text(root,width=69,height=25)#多行文本框测试成功
#txt2.insert(1.0,"123")#注意单独使用place()，Text.insert才能使用
txt2.place(x=12,y=10)
lbl2=tkinter.Label(root,text="输入信息").place(x=10,y=350)
v1=tkinter.StringVar();v1.set('123abc')
txt1=tkinter.Entry(root,textvariable=v1,width=50).place(x=70,y=350)
btn1=tkinter.Button(root,text="发送",command=onSend,width=8).place(x=435,y=350)
#v2=tkinter.StringVar();v2.set('')#巧妙：字符串缓冲区，此处保留
#txt2=tkinter.Listbox(root,listvariable=v2,width=69,height=24).place(x=12,y=10)#列表显示测试成功
n=tkinter.IntVar();n.set(0) #巧妙：定义计数器，此处保留
root.mainloop()

