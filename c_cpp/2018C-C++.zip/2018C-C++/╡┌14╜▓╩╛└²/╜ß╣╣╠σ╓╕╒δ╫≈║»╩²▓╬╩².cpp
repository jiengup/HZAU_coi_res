#include<stdio.h>
typedef struct date
{
    int year;
    int month;
    int day;
}DATE;
void func(DATE *p)
{
    p->year=2000;
    p->month=5;
    p->day=22;
}
int main()
{
    DATE d;
    d.year=2018;
    d.month=11;
    d.day=5;
    printf("Before function call: %d/%02d/%02d\n",d.year,d.month,d.day);
    func(&d);
    printf("After function call: %d/%02d/%02d\n",d.year,d.month,d.day);
    return 0;
}
