#include<stdio.h>
int main()
{
    int num;
    int sum=0;
    do{
        printf("input num:");
        scanf("%d",&num);
        sum=sum+num;
        printf("sum=%d\n",sum);
    }while(num!=0);
    return 0;
}
