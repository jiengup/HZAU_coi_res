#include <stdio.h>
int main()
{
    int month;
    printf("Input month:");
    scanf("%d", &month);
    switch(month)
    {
    case 1:
        printf("January\n");
        break;
    case 2:
        printf("February\n");

    case 3:
        printf("March\n");
        break;
    default:
        printf("other\n");
        break;
    }
    printf("end\n");
    return 0;
}
