#include<stdio.h>
long Fib(int n);
//int count;//ȫ�ֱ���
int main()
{
    int count;
    int n,i,x;
    printf("Input the number of n:");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        count=0;
        x=Fib(i);
        printf("Fib(%d)= %d, count=%d\n",i,x,count);
    }
    return 0;
}
long Fib(int n)
{
	long f;
	int count;
    count++;
	if (n == 0) f = 0;
	else if (n == 1) f = 1;
	else f = Fib(n-1) + Fib(n-2);
	return f;
}
