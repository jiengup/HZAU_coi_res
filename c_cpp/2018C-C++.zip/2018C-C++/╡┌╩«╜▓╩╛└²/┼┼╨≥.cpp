#include <stdio.h>
#define N 40
int ReadScore(int score[]);
void PrintScore(int score[],int n);
void DataSortExchange(int score[],int n);
void DataSortSelection(int score[], long num[], int n);
int main()
{
    int score[N], max,n;

    n=ReadScore(score);
    printf("Total students are %d\n",n);
    DataSortExchange(score,n);
    PrintScore(score,n);
    return 0;
}

int ReadScore(int score[])
{
    int i=-1;
    printf("input score:");
    do{
        i++;
        scanf("%d",&score[i]);
    }while(score[i]>=0);

    return i;
}
void PrintScore(int score[],int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("%d ",score[i]);
    }
}
void DataSortExchange(int score[],int n)//������
{
    int i,j,temp;
    for(i=0;i<n-1;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(score[j]>score[i])
            {
                temp=score[j];
                score[j]=score[i];
                score[i]=temp;
            }
        }
    }
}
void DataSortSelection(int score[], long num[], int n) /*ѡ��*/
{
    int i, j, k, temp1;
    long temp2;
    for (i=0; i<n-1; i++)
    {
        k = i;
        for (j=i+1; j<n; j++)
        {
            if (score[j] > score[k])
            {
                k = j;    /*��¼������±�λ��*/
            }
        }
        if (k != i)       /*������������±�λ��i*/
        {
	      	temp1 = score[k];
            score[k] = score[i];
	      	score[i] = temp1;
            temp2 = num[k];
            num[k] = num[i];
            num[i] = temp2;
        }
    }
}

