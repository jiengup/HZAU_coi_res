#实验5.5 综合Web编程-Django框架
#Django是重量级全栈Full Stack Web开发框架
#程序代码在django_web目录中
'''
django_web目录说明
(1) django_web目录：包含：
    home子目录、myweb子目录、dbsqlite3数据库文件、manage.py管理文件
(2) home目录：是django_web子目录,是系统生成目录，包含：
    _pycache_:python系统缓冲目录
    migrations:文件迁移备份目录
    __init__.py:系统初始文件
    admin.py:系统管理文件
    apps.py:应用文件
    http.py:自建文件
    models.py: 模型文件
    tests.py:测试文件
    views.py:视图文件
(3) myweb目录：是django_web子目录，是用户创建目录，目录名首次创建可更改，包含：
    _pycache_:python用户缓冲目录    
    __init__.py:用户初始文件
    settings.py:用户配置文件
    urls.py: 用户url配置文件
    wsgi.py: 用户服务配置文件
(4) sqlitestudio3.1.1:数据库可视化查看文件，自加目录
(5) db.sqlite3:数据库文件
(6) manage.py:管理操作文件
'''

"""
Python+Django+SQLite3:开发Web程序
  Django后台创建与SQLite3配置：参考word文档（实验5.5 Django后台创建与SQLite3配置）
"""

