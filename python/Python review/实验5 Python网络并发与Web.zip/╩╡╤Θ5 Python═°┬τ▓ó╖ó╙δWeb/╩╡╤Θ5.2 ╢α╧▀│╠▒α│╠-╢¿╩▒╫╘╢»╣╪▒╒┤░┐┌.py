#实验5.2 多线程编程 实现定时自动关闭窗口
import time
import tkinter
import threading
import os

#创建应用程序窗口，设置标题和大小
win=tkinter.Tk()
win.title("倒计时自动关闭窗口")
win["width"]=400
win["height"]=300

#不允许改变窗口大小
win.resizable(False, False)

#创建Text组件，放置一些文字
richText=tkinter.Text(win, width=380)
richText.place(x=10,y=10, width=380, height=180)
richText.insert('0.0',"假设阅读这些文字需要10秒钟时间")

#显示倒计时Label
lblTime1=tkinter.Label(win,fg='red',anchor='w')
lblTime1.place(x=10,y=200,width=150)
lblTime2=tkinter.Label(win,fg='green',anchor='w')
lblTime2.place(x=10,y=230,width=150)
lblTime3=tkinter.Label(win,fg='blue',anchor='w')
lblTime3.place(x=10,y=260,width=150)

def autoClose1():
    for i in range(60):
        lblTime1["text"]="距离窗口关闭还有{}秒".format(10-i)
        time.sleep(1)    
    os._exit(0)#关闭窗口
    #win.destroy()
    
def autoClose2():
    for i in range(70):
        lblTime2["text"]="距离窗口关闭还有{}秒".format(20-i)
        time.sleep(1)
    win.destroy()

def autoClose3():
    for i in range(80):
        lblTime3["text"]="距离窗口关闭还有{}秒".format(30-i)
        time.sleep(1)
    win.destroy()
    
#创建并启动线程
t1=threading.Thread(target=autoClose1)
t1.start()
t2=threading.Thread(target=autoClose2)
t2.start()
t3=threading.Thread(target=autoClose3)
t3.start()
win.mainloop()


