#include <stdio.h>
#define N 40
void ReadScore(int score[],int n);
int Average(int score[],int n);
int main()
{
    int score[N], aver,n;
    printf("input n:");
    scanf("%d",&n);
    ReadScore(score,n);
    aver=Average(score,n);
    printf("average score is %d\n",aver);
    return 0;
}

void ReadScore(int score[],int n)
{
    int i;
    printf("input score:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&score[i]);
    }
}
int Average(int score[],int n)
{
    int i,sum=0;
    for(i=1;i<n;i++)
    {
        sum+=score[i];
    }
    return sum/n;
}
