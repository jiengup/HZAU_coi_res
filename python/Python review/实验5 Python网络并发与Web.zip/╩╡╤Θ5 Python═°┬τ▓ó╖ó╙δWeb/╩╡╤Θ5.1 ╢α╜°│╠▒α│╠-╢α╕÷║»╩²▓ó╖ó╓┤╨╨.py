#实验5.1 多进程编程 实现多个函数并发执行
'''
（1）multiprocessing:多进程包，支持子进程、通信和共享数据、执行不同形式的同步，提供Process、Queue、Pipe、Lock等组件
     pip3 install multiprocessing
（2）Process:创建进程的类
     格式：Process([group[,target[,name[,args[,kwargs]]]]])  
          target表示调用对象，args表示调用对象的位置参数元组，kwargs表示调用对象的字典，name为别名，group实质上不使用
     方法：is_alive()、join([timeout])、run()、start()启动进程、terminate()
     属性：authkey、daemon(通过start()设置)、exitcode、name、pid
'''
import multiprocessing as mp  #注意不是multiprocess
import time

def worker_1(interval):
    print("worker_1 start.",end='  ')
    time.sleep(interval)
    print("worker_1 end.",end='  ')

def worker_2(interval):
    print("worker_2 start.",end='  ')
    time.sleep(interval)
    print("worker_2 end.",end='  ')

def worker_3(interval):
    print("worker_3 start.",end='  ')
    time.sleep(interval)
    print("worker_3 end.",end='  ')

def worker_4(interval):
    print("worker_4 start.")
    time.sleep(interval)
    print("worker_4 end.")
    
def worker_5(interval):
    print("worker_5 start.",end='  ')
    time.sleep(interval)
    print("worker_5 end.",end='  ')

def worker_6(interval):
    print("worker_6 start.",end='  ')
    time.sleep(interval)
    print("worker_6 end.",end='  ')

def worker_7(interval):
    print("worker_7 start.",end='  ')
    time.sleep(interval)
    print("worker_7 end.",end='  ')

def worker_8(interval):
    print("worker_8 start.")
    time.sleep(interval)
    print("worker_8 end.")

def main():
    print("------------------------------START------------------------------")

    p1=mp.Process(target=worker_1,args=(1,)) #1秒
    p2=mp.Process(target=worker_2,args=(2,)) #2秒
    p3=mp.Process(target=worker_3,args=(3,)) #3秒
    p4=mp.Process(target=worker_4,args=(4,)) #4秒
    p5=mp.Process(target=worker_5,args=(5,)) #5秒
    p6=mp.Process(target=worker_6,args=(6,)) #6秒
    p7=mp.Process(target=worker_7,args=(7,)) #7秒
    p8=mp.Process(target=worker_8,args=(8,)) #8秒

    p1.start(); p2.start(); p3.start(); p4.start()
    p5.start(); p6.start(); p7.start(); p8.start()

    print("The number of CPU is:"+str(mp.cpu_count()))
    n=0
    for p in mp.active_children():
        print("child p.name:%s"%p.name,"p.id:%5s"%str(p.pid),end='  ')
        n+=1
        if n%2==0:
             print()
    print("-------------------------------END------------------------------")

if __name__=="__main__":
    main()
