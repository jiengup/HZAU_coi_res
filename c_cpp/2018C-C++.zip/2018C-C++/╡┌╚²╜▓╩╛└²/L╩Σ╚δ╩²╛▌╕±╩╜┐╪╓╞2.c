#include  <stdio.h>
main()
{
	int  a, b;
	scanf("%d, %d", &a, &b);
	printf("a = %d, b = %d\n", a, b);
}
